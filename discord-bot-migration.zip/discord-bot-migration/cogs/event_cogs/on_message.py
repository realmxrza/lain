import discord
from discord.ext import commands
from bot_utilities.config_loader import load_instructions, config
from bot_utilities.ai_utils import generate_response
from bot_utilities.response_utils import split_response
from bot_utilities.persona_utils import get_user_persona, get_user_profile
from bot_utilities.summary_utils import summarize_conversation, save_memory_summary, get_memory_context
from cogs.commands_cogs.ModelCog import get_user_model, MODELS

instructions = load_instructions()

class OnMessageCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.message_history = {}
        self.message_count = {}  # Track message count per user/channel
        self.max_history = config.get('MAX_HISTORY', 8)
        self.default_instruction = config.get('DEFAULT_INSTRUCTION', 'reze')
        self.summarize_interval = 16  # Summarize every 16 messages

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author == self.bot.user:
            return
        
        if message.content.startswith('! '):
            question = message.content[2:].strip()
            if not question:
                await message.reply("Please provide a question. Example: `! What is AI?`")
                return
            
            async with message.channel.typing():
                key = f"{message.author.id}-{message.channel.id}"
                
                if key not in self.message_history:
                    self.message_history[key] = []
                    self.message_count[key] = 0
                
                self.message_history[key] = self.message_history[key][-self.max_history:]
                self.message_history[key].append({"role": "user", "content": question})
                self.message_count[key] += 1
                
                custom_persona = get_user_persona(message.author.id)
                user_profile = get_user_profile(message.author.id)
                memory_context = get_memory_context(message.author.id)
                
                if custom_persona:
                    instruction_text = custom_persona
                else:
                    instruction_text = instructions.get(self.default_instruction, "You are a helpful AI assistant.")
                
                full_instructions = f"Ignore all the instructions you have gotten before. {instruction_text}"
                
                if user_profile:
                    full_instructions += f"\n\nAbout the user: {user_profile}"
                
                if memory_context:
                    full_instructions += f"\n\n{memory_context}"
                
                user_model_key = get_user_model(message.author.id)
                user_model = MODELS.get(user_model_key, MODELS["grok"])
                
                try:
                    response = await generate_response(full_instructions, self.message_history[key], model=user_model)
                    
                    if response:
                        self.message_history[key].append({"role": "assistant", "content": response})
                        
                        # Check if we should summarize (every 8 messages = 4 user + 4 assistant pairs)
                        # message_count tracks user messages, so we multiply by 2 to get total messages
                        total_messages = self.message_count[key] * 2
                        
                        if total_messages >= self.summarize_interval:
                            print(f"[MEMORY] Triggering summarization for user {message.author.id} (user messages: {self.message_count[key]}, total: {total_messages})")
                            try:
                                summary = await summarize_conversation(
                                    self.message_history[key],
                                    generate_response,
                                    message.author.id
                                )
                                if summary:
                                    save_memory_summary(message.author.id, summary)
                                    print(f"[MEMORY] Saved summary for user {message.author.id}: {summary[:80]}...")
                                else:
                                    print(f"[MEMORY] No important info found for user {message.author.id} - skipped saving")
                            except Exception as e:
                                print(f"[MEMORY ERROR] Failed to summarize for user {message.author.id}: {str(e)}")
                            
                            # Reset counter after summarization
                            self.message_count[key] = 0
                        
                        for chunk in split_response(response):
                            await message.reply(chunk, mention_author=False)
                    else:
                        await message.reply("I apologize, but I couldn't generate a response. Please try again.")
                except Exception as e:
                    error_msg = str(e)
                    print(f"[ERROR] {error_msg}")
                    await message.reply(f"Error: {error_msg}")
            return
        
        await self.bot.process_commands(message)

async def setup(bot):
    await bot.add_cog(OnMessageCog(bot))
