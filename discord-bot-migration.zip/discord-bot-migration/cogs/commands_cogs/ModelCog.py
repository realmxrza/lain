import discord
from discord.ext import commands
import json
import os
from typing import Optional

MODELS = {
    "grok": "x-ai/grok-4.1-fast:free",
    "deepseek": "tngtech/deepseek-r1t2-chimera:free",
    "gemma": "google/gemma-3-27b-it:free",
    "uncensored": "cognitivecomputations/dolphin-mistral-24b-venice-edition:free",
}

MODEL_FILE = "user_models.json"

def load_user_models():
    if os.path.exists(MODEL_FILE):
        with open(MODEL_FILE, 'r') as f:
            return json.load(f)
    return {}

def save_user_models(models):
    with open(MODEL_FILE, 'w') as f:
        json.dump(models, f, indent=4)

def get_user_model(user_id):
    models = load_user_models()
    return models.get(str(user_id), "grok")

def set_user_model(user_id, model_key):
    models = load_user_models()
    models[str(user_id)] = model_key
    save_user_models(models)

class ModelCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.hybrid_command(name="model", description="Switch AI model")
    @discord.app_commands.describe(model="Model to use (grok, deepseek, gemma, or uncensored)")
    async def model(self, ctx, *, model: Optional[str] = None):
        if ctx.interaction is None:
            return
        
        if model is None:
            current = get_user_model(ctx.author.id)
            await ctx.send(f"Current model: **{current}**\nAvailable models: {', '.join(MODELS.keys())}")
            return
        
        model_lower = model.lower()
        if model_lower not in MODELS:
            await ctx.send(f"Unknown model. Available: {', '.join(MODELS.keys())}")
            return
        
        set_user_model(ctx.author.id, model_lower)
        await ctx.send(f"Model switched to **{model_lower}**")

async def setup(bot):
    await bot.add_cog(ModelCog(bot))
