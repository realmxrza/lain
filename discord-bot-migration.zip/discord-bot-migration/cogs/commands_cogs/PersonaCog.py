import discord
from discord.ext import commands
from bot_utilities.persona_utils import (
    set_user_persona, get_user_persona, delete_user_persona,
    set_user_profile, get_user_profile, delete_user_profile
)
from bot_utilities.summary_utils import load_user_memory, reset_user_memory

class PersonaCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.hybrid_group(name="persona", description="Manage your custom character persona", invoke_without_command=True)
    async def persona(self, ctx):
        """Persona management command group"""
        if ctx.invoked_subcommand is None:
            await ctx.send("Use `/persona set`, `/persona view`, or `/persona reset`")

    @persona.command(name="set", description="Set your custom character persona")
    @discord.app_commands.describe(text="Your custom persona description")
    async def set_persona(self, ctx, *, text: str):
        """Set a custom persona for the user"""
        if len(text) < 50:
            await ctx.send("Persona must be at least 50 characters long.")
            return
        
        if len(text) > 2000:
            await ctx.send("Persona must be under 2000 characters.")
            return
        
        set_user_persona(ctx.author.id, text)
        await ctx.send("Your custom persona has been set! I'll use it from now on.")

    @persona.command(name="view", description="View your current persona")
    async def view_persona(self, ctx):
        """View the user's current persona"""
        persona = get_user_persona(ctx.author.id)
        
        if not persona:
            await ctx.send("You haven't set a custom persona yet. Use `/persona set` to create one.")
            return
        
        if len(persona) > 1900:
            await ctx.send(f"Your persona (truncated):\n{persona[:1900]}...")
        else:
            await ctx.send(f"Your persona:\n{persona}")

    @persona.command(name="reset", description="Reset to default persona")
    async def reset_persona(self, ctx):
        """Delete user's custom persona"""
        if delete_user_persona(ctx.author.id):
            await ctx.send("Your custom persona has been removed. I'll use the default persona.")
        else:
            await ctx.send("You don't have a custom persona set.")

    @commands.hybrid_group(name="user_profile", description="Manage your user profile", invoke_without_command=True)
    async def user_profile(self, ctx):
        """User profile management command group"""
        if ctx.invoked_subcommand is None:
            await ctx.send("Use `/user_profile set`, `/user_profile view`, or `/user_profile reset`")

    @user_profile.command(name="set", description="Set your user profile")
    @discord.app_commands.describe(text="Tell me about yourself")
    async def set_profile(self, ctx, *, text: str):
        """Set a profile for the user"""
        if len(text) < 20:
            await ctx.send("Profile must be at least 20 characters long.")
            return
        
        if len(text) > 2000:
            await ctx.send("Profile must be under 2000 characters.")
            return
        
        set_user_profile(ctx.author.id, text)
        await ctx.send("Your profile has been saved! I'll use it when responding to you.")

    @user_profile.command(name="view", description="View your user profile")
    async def view_profile(self, ctx):
        """View the user's profile"""
        profile = get_user_profile(ctx.author.id)
        
        if not profile:
            await ctx.send("You haven't set a profile yet. Use `/user_profile set` to create one.")
            return
        
        if len(profile) > 1900:
            await ctx.send(f"Your profile (truncated):\n{profile[:1900]}...")
        else:
            await ctx.send(f"Your profile:\n{profile}")

    @user_profile.command(name="reset", description="Delete your user profile")
    async def reset_profile(self, ctx):
        """Delete user's profile"""
        if delete_user_profile(ctx.author.id):
            await ctx.send("Your profile has been removed.")
        else:
            await ctx.send("You don't have a profile set.")

    @commands.hybrid_command(name="memory", description="View your saved memory")
    async def memory(self, ctx):
        """View user's saved memory"""
        if ctx.interaction is None:
            return
        
        memory = load_user_memory(ctx.author.id)
        if memory:
            memory_text = "\n".join(memory)
            if len(memory_text) > 1900:
                await ctx.send(f"Your saved memory (truncated):\n{memory_text[:1900]}...")
            else:
                await ctx.send(f"Your saved memory:\n{memory_text}")
        else:
            await ctx.send("You don't have any saved memory yet. Chat with me and I'll learn about you!")

    @commands.hybrid_command(name="memory_reset", description="Clear all your saved memory")
    async def memory_reset(self, ctx):
        """Delete user's saved memory"""
        if ctx.interaction is None:
            return
        
        memory = load_user_memory(ctx.author.id)
        if memory:
            reset_user_memory(ctx.author.id)
            await ctx.send("Your saved memory has been cleared. I'll start fresh with you!")
        else:
            await ctx.send("You don't have any saved memory to clear.")

async def setup(bot):
    await bot.add_cog(PersonaCog(bot))
