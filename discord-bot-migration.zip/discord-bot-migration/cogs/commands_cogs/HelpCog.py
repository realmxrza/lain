import discord
from discord.ext import commands


class HelpCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.hybrid_command(name="help", description="Get all available commands")
    async def help(self, ctx):
        embed = discord.Embed(title="Bot Commands", color=0x9370DB)
        if self.bot.user.avatar:
            embed.set_thumbnail(url=self.bot.user.avatar.url)
        
        embed.add_field(name="Quick Ask (Prefix Only)", value="`! Your question here` - Ask Reze anything without typing 'ask'", inline=False)
        embed.add_field(name="---", value="", inline=False)
        
        command_tree = self.bot.commands
        for command in command_tree:
            if command.hidden:
                continue
            command_description = command.description or "No description available"
            embed.add_field(name=f"/{command.name}",
                            value=command_description, inline=False)

        await ctx.send(embed=embed)


async def setup(bot):
    await bot.add_cog(HelpCog(bot))
