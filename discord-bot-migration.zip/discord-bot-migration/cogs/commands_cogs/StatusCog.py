import discord
from discord.ext import commands
from datetime import datetime, timedelta
import time

class StatusCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.start_time = time.time()

    @commands.hybrid_command(name="status", description="Show bot status and statistics")
    async def status(self, ctx):
        uptime_seconds = time.time() - self.start_time
        uptime = timedelta(seconds=int(uptime_seconds))
        
        embed = discord.Embed(title="Bot Status", color=0x9370DB)
        if self.bot.user.avatar:
            embed.set_thumbnail(url=self.bot.user.avatar.url)
        
        embed.add_field(name="Status", value="Online", inline=True)
        embed.add_field(name="Uptime", value=str(uptime), inline=True)
        embed.add_field(name="Latency", value=f"{round(self.bot.latency * 1000)}ms", inline=True)
        embed.add_field(name="AI Provider", value="OpenRouter", inline=True)
        
        embed.add_field(name="---", value="", inline=False)
        embed.add_field(name="Models Available", value="• **grok** - Grok 4.1 Fast\n• **deepseek** - DeepSeek R1T2 Chimera\n• **gemma** - Google's Gemma\n• **uncensored** - Uncensored Mistral", inline=False)
        embed.add_field(name="Personality", value="Reze", inline=False)
        
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(StatusCog(bot))
