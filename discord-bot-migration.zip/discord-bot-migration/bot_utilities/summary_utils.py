import json
import os
from pathlib import Path

MEMORY_FILE = "user_memory.json"

def load_user_memory(user_id):
    """Load all memory summaries for a user"""
    if not os.path.exists(MEMORY_FILE):
        return None
    
    try:
        with open(MEMORY_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
            return data.get(str(user_id))
    except Exception as e:
        print(f"[ERROR] Failed to load memory: {str(e)}")
        return None

def save_memory_summary(user_id, summary):
    """Save a new memory summary for user"""
    if not summary or summary.strip() == "":
        return  # Don't save empty summaries
    
    # Load existing data
    data = {}
    if os.path.exists(MEMORY_FILE):
        try:
            with open(MEMORY_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
        except Exception as e:
            print(f"[ERROR] Failed to load existing memory: {str(e)}")
            data = {}
    
    user_id_str = str(user_id)
    
    # Initialize user's memory if needed
    if user_id_str not in data:
        data[user_id_str] = []
    
    # Add new summary
    data[user_id_str].append(summary)
    
    # Save
    with open(MEMORY_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def get_memory_context(user_id):
    """Get formatted memory context for AI instructions"""
    memory = load_user_memory(user_id)
    
    if not memory or len(memory) == 0:
        return ""
    
    # Join all summaries into one context string
    context = "\n".join(memory)
    return f"Remembered context about the user:\n{context}"

async def summarize_conversation(history, ai_generate_fn, user_id):
    """
    Summarize last 16 messages to extract important user info.
    Only returns summary if important info found.
    """
    if len(history) < 2:
        return None
    
    # Get last 16 messages for summarization
    recent_messages = history[-16:]
    
    # Format conversation for summarization
    conversation = "\n".join([
        f"{msg['role'].upper()}: {msg['content'][:200]}"  # Truncate long messages
        for msg in recent_messages
    ])
    
    summarization_prompt = f"""You are analyzing a Discord chat conversation. Your job is to extract ONLY important information about the user that would be useful to remember for future conversations.

Conversation:
{conversation}

Extract ANY of these if mentioned:
- Name, nickname, username
- Age, location, background, ethnicity, nationality
- Job, profession, school, company
- Skills, languages, expertise
- Hobbies, interests, preferences
- Personal goals, projects they're working on
- Personality traits

Ignore:
- Random small talk or generic greetings
- Questions about features or how to use the bot
- Temporary topics that won't matter later

If there's NOTHING important to remember about the user, respond with exactly: "NOTHING_IMPORTANT"

Otherwise, write a brief 1-2 sentence summary of what's important to remember about this user."""
    
    try:
        # Use the same AI system to generate summary
        summary = await ai_generate_fn(
            "You are a memory assistant. Extract important user context concisely.",
            [{"role": "user", "content": summarization_prompt}],
            model=None
        )
        
        # Check if summary is meaningful
        if summary and "NOTHING_IMPORTANT" not in summary:
            return summary.strip()
        
        return None
    except Exception as e:
        print(f"[ERROR] Failed to summarize: {str(e)}")
        return None

def reset_user_memory(user_id):
    """Clear all memory for a user"""
    if not os.path.exists(MEMORY_FILE):
        return
    
    try:
        with open(MEMORY_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        user_id_str = str(user_id)
        if user_id_str in data:
            del data[user_id_str]
            
            with open(MEMORY_FILE, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
    except Exception as e:
        print(f"[ERROR] Failed to reset memory: {str(e)}")
