import json
import os

USER_PERSONAS_FILE = "user_personas.json"
USER_PROFILES_FILE = "user_profiles.json"

def load_user_personas():
    """Load all custom user personas"""
    if os.path.exists(USER_PERSONAS_FILE):
        with open(USER_PERSONAS_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {}

def save_user_personas(personas):
    """Save user personas to file"""
    with open(USER_PERSONAS_FILE, 'w', encoding='utf-8') as f:
        json.dump(personas, f, indent=2, ensure_ascii=False)

def get_user_persona(user_id):
    """Get custom persona for a user, returns None if not set"""
    personas = load_user_personas()
    user_id_str = str(user_id)
    return personas.get(user_id_str)

def set_user_persona(user_id, persona_text):
    """Set custom persona for a user"""
    personas = load_user_personas()
    user_id_str = str(user_id)
    personas[user_id_str] = persona_text
    save_user_personas(personas)

def delete_user_persona(user_id):
    """Delete custom persona for a user"""
    personas = load_user_personas()
    user_id_str = str(user_id)
    if user_id_str in personas:
        del personas[user_id_str]
        save_user_personas(personas)
        return True
    return False

def load_user_profiles():
    """Load all user profiles"""
    if os.path.exists(USER_PROFILES_FILE):
        with open(USER_PROFILES_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {}

def save_user_profiles(profiles):
    """Save user profiles to file"""
    with open(USER_PROFILES_FILE, 'w', encoding='utf-8') as f:
        json.dump(profiles, f, indent=2, ensure_ascii=False)

def get_user_profile(user_id):
    """Get profile for a user, returns None if not set"""
    profiles = load_user_profiles()
    user_id_str = str(user_id)
    return profiles.get(user_id_str)

def set_user_profile(user_id, profile_text):
    """Set profile for a user"""
    profiles = load_user_profiles()
    user_id_str = str(user_id)
    profiles[user_id_str] = profile_text
    save_user_profiles(profiles)

def delete_user_profile(user_id):
    """Delete profile for a user"""
    profiles = load_user_profiles()
    user_id_str = str(user_id)
    if user_id_str in profiles:
        del profiles[user_id_str]
        save_user_profiles(profiles)
        return True
    return False
